package com.hospital.management.hospital.service;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Getter
@Setter

public class LoginReq {

    String userName ;
    String password;



}
