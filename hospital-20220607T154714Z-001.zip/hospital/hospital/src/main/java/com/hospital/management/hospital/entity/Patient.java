package com.hospital.management.hospital.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Getter
@Setter
@Table(name = "patient_tbl")
@AllArgsConstructor
@NoArgsConstructor
public class Patient {
    @Id
    @Column(name="patient_id")
    @GeneratedValue
    private long patientId;

    @Column(name="patient_name")
    private String patientName;

    @Column(name="gender")
    private String gender;

    @Column(name="age")
    private int age;

    @Column(name="dateofbirth")
    private Date  dateOfBirth;

    @Column(name="email_id")
    private String emailId;

    @Column(name="maritalstatus")
    private String maritalStatus;

    @Column(name="contact_no")
    private int contactNo;


    @Column(name="address")
    private  String address;

    @Column(name=" doctor_name")
    private  String doctorName;

    @Column(name="reason")
    private   String reason;;

    @Column(name="admit_date")
    private LocalDateTime admitDate;

   /* @ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", nullable = false)
    private Department department;*/

}